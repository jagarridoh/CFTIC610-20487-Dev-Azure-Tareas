﻿using System;
using System.Collections.Generic;

namespace AutoRest.Client
{
    class Program
    {
        static void Main(string[] args)
        {
            
        }
    }
}
