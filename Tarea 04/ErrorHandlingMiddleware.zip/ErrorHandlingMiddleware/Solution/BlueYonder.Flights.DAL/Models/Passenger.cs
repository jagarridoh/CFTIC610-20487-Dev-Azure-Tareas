namespace BlueYonder.Flights.DAL.Models
{
    public class Passenger
    {
        public int PassengerId { get; set; }
        public string Name { get; set; }
        public string Email { get; set; }
    }
}