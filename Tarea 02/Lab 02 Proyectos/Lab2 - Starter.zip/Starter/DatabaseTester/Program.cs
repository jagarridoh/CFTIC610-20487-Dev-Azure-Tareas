﻿using System;
using DAL.Database;
using DAL.Models;
using System.Linq;
using System.Collections.Generic;
using DAL.Repository;
using Microsoft.EntityFrameworkCore;
using System.Threading.Tasks;

namespace DatabaseTester
{
    class Program
    {
        static async Task Main(string[] args)
        {
             
        }
    }
}
